import React from 'react'
import WeatherApp from './Components/Weather_app'

const App = () => {
  return (
    <>
      <WeatherApp />
    </>
  )
}

export default App